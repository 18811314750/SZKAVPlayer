# SZKAVPlayer
iOS在线音乐播放SZKAVPlayer（基于系统AVPlayer的封装）  提供播放暂停，上一首，下一首接口，并用代理方法返回当前时间，总共时间，歌曲进度等。


详细文档请点击  简书：http://www.jianshu.com/p/4e0ac2898de0



创建SZKAVPlayer

/**
 *  初始化SZKAVPlayer
 *
 *  @param frame  AVPlayerLayer的frame
 *  @param urlArr 歌曲网址的数组
 *  @param urlArr 歌曲背景图片网址的数组
 *
 *  @return   SZKAVPlayer
 */
```
-(instancetype)initWithFrame:(CGRect)frame
               andSongUrlArr:(NSArray *)urlArr
             andSongImageArr:(NSArray *)imageArr;
 ```

/**
 *  开始播放
 */
```
-(void)startPlay;
```
/**
 *  暂停播放
 */
```
-(void)puasePlay;
```
/**
 *  播放下一首
 */
 
```
-(void)nextSong;
```
/**
 *  播放上一首
 */
 
```
-(void)lastSong;
```


返回的代理方法可以获取当前时间，总共时间，歌曲进度，点击次数等
/**
 *  author  SZK
 *
 *  @param currentTime 当前时间
 *  @param totalTime   总共时间
 *  @param progress    歌曲进度
 *  @param tapCount    点击次数
 */
 
```
-(void)getSongCurrentTime:(NSString *)currentTime andTotalTime:(NSString *)totalTime andProgress:(CGFloat)progress andTapCount:(NSInteger)tapCount;
```


