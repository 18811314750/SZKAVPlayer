//
//  SZKAVPlayer.h
//  AVPlayer
//
//  Created by sunzhaokai on 16/4/15.
//  Copyright © 2016年 孙赵凯. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol SZKAVPlayerDelegate <NSObject>
/**
 *  author  孙赵凯 QQ/微信:790057066
 *
 *  @param currentTime 当前时间
 *  @param totalTime   总共时间
 *  @param progress    歌曲进度
 *  @param tapCount    点击次数
 */
-(void)getSongCurrentTime:(NSString *)currentTime andTotalTime:(NSString *)totalTime andProgress:(CGFloat)progress andTapCount:(NSInteger)tapCount;
@end

@interface SZKAVPlayer :  UIView
/**
 *  songDelegate
 */
@property(nonatomic,retain)id<SZKAVPlayerDelegate>delegate;
/**
 *  volume 0.0~1.0
 */
@property(nonatomic,assign)CGFloat volume;
/**
 *  初始化SZKAVPlayer
 *
 *  @param frame  AVPlayerLayer的frame
 *  @param urlArr 歌曲网址的数组
 *  @param urlArr 歌曲背景图片网址的数组
 *
 *  @return   SZKAVPlayer
 */
-(instancetype)initWithFrame:(CGRect)frame
               andSongUrlArr:(NSArray *)urlArr
             andSongImageArr:(NSArray *)imageArr;
/**
 *  开始播放
 */
-(void)startPlay;
/**
 *  暂停播放
 */
-(void)puasePlay;
/**
 *  播放下一首
 */
-(void)nextSong;
/**
 *  播放上一首
 */
-(void)lastSong;



@end
